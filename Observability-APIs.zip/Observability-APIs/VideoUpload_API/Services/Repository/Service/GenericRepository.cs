﻿using VideoUpload_API.Services.Repository.Interface;

namespace VideoUpload_API.Services.Repository.Service
{
    public abstract class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        #region Properties

        protected IConfiguration Config { get; }

        #endregion

        #region Constructor

        protected GenericRepository(IConfiguration configuration)
        {
            Config = configuration;
        }

        #endregion

        public abstract Task<int> InsertAsync(T entity);

        public abstract Task<IEnumerable<T>> GetAllAsync();

        public abstract Task<T> FindAsync(int id);

        public abstract Task<int> UpdateAsync(T entityToUpdate);

        public abstract Task<int> DeleteAsync(int id);
    }
}
