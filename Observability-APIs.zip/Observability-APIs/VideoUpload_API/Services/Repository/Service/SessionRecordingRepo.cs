﻿using Dapper;
using System.Data;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using VideoUpload_API.Database.Dapper;
using VideoUpload_API.Models.Dto;
using VideoUpload_API.Services.Repository.Interface;

namespace VideoUpload_API.Services.Repository.Service
{
    public class SessionRecordingRepo : GenericRepository<ClsVideoSubmitDto>, ISessionRecordingRepo
    {

        #region Property

        ClsDbConnection ConnectionManager;
        private IConfiguration configuration { get; set; }

        #endregion

        #region Constructor


        public SessionRecordingRepo(IConfiguration _configuration) : base(_configuration)
        {
            configuration = _configuration;
            ConnectionManager = ClsDbConnection.SingleInstance;
        }

        #endregion

        #region Destructor
        ~SessionRecordingRepo()
        {
            Dispose(false);
        }

        #endregion

        public async Task SaveChunkAsync(Guid sessionId, int chunkNumber, string rootFolder, string appName, JsonElement events, CancellationToken cancellationToken)
        {
            try
            {
                if (sessionId == Guid.Empty)
                    throw new ArgumentException("Invalid session ID.");

                if (chunkNumber < 0)
                    throw new ArgumentOutOfRangeException(
                        nameof(chunkNumber));

                if (events.ValueKind != JsonValueKind.Array)
                    throw new ArgumentException(
                        "Events must be a JSON array.");

                // S3 folder structure is represented by object prefixes.
                // No physical folder creation is required.

                rootFolder = rootFolder + "SessionRecording" + "\\" + appName;

                string sessionFolder = Path.Combine(rootFolder, sessionId.ToString("D"));

                string chunkFolder = Path.Combine(sessionFolder, "chunks");

                // Create folder if does not exit
                Directory.CreateDirectory(chunkFolder);

                // Generate chunk file name
                var filename = $"{chunkNumber:DB}.json";

                string filePath = Path.Combine(chunkFolder, filename);

                // Generate JSON payload
                var payload = JsonSerializer.Serialize(new
                {
                    sessionId,
                    chunkNumber,
                    uploadedUtc = DateTimeOffset.UtcNow,
                    events
                });

                var bytes = Encoding.UTF8.GetBytes(payload);

                // Generate SHA-256 hash
                var hash = Convert.ToHexString(
                    SHA256.HashData(bytes));


                string query_vdoupload = "INSERT INTO txnvideoupload(chunknumber,chunknofilename,appname,sessionid,CreationAt) values(@chunknumber,@chunknofilename,@appname,@sessionid,@CreationAt)";
                using (IDbConnection cn = ConnectionManager.getConnectionString(configuration))
                {
                    cn.Execute(query_vdoupload, new { chunknumber = chunkNumber, chunknofilename = filename, appname = appName, sessionid = sessionId.ToString("D"), CreationAt = DateTime.Now });
                }

                // Prevent overwriting an eisting chunk

                await using (var fileStream = new FileStream(filePath, FileMode.CreateNew, FileAccess.Write, FileShare.None, bufferSize: 81920, useAsync: true))
                {
                    await fileStream.WriteAsync(bytes, cancellationToken);
                }

                var hashFilePath = filePath + ".sha256";

                await File.WriteAllTextAsync(hashFilePath, hash, cancellationToken);

                //_logger.LogInformation("Session chunk save locally. SessionId: {sessionId} , Chunk: {chunkNumber}, Path: {FilePath}", sessionId, chunkNumber, filePath);
            }
            catch (IOException ex)
                when (ex.Message.Contains("exist", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException("This session chunk already exits", ex);
            }
            catch (Exception ex)
            {
                //_logger.LogError(ex, "Failed to save session chunk locally. SessionId: {sessionId} , Chunk : {chunkNumber}", sessionId, chunkNumber);
                throw;
            }
        }

        public async Task<Guid> CreateSessionAsync(string appName)
        {
            try
            {
                var sql = @"
                        INSERT INTO txnvideosubmit
                        (
                            appname,
                            IsActive,
                            Iscombinchunk,
                            IsMp4converstion,
                            CreationAt,
                            LastModifiedAt
                        )
                        OUTPUT INSERTED.sessionId
                        VALUES
                        (
                            @appname,
                            1,
                            0,
                            0,
                            GETDATE(),
                            GETDATE()
                        );";

                using (IDbConnection cn = ConnectionManager.getConnectionString(configuration))
                {
                    return await cn.QuerySingleAsync<Guid>(
                    sql,
                    new { appname = appName });
                }
            }
            catch(Exception ex)
            {
                throw;
            }
        }
        public override Task<int> InsertAsync(ClsVideoSubmitDto entity)
        {
            throw new NotImplementedException();
        }
        public override Task<IEnumerable<ClsVideoSubmitDto>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public override Task<ClsVideoSubmitDto> FindAsync(int id)
        {
            throw new NotImplementedException();
        }

        public override Task<int> UpdateAsync(ClsVideoSubmitDto entityToUpdate)
        {
            throw new NotImplementedException();
        }

        public override Task<int> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }


        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                // Console.WriteLine("This is the first call to Dispose. Necessary clean-up will be done!");

                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                    // Console.WriteLine("Explicit call: Dispose is called by the user.");
                }
                else
                {
                    // Console.WriteLine("Implicit call: Dispose is called through finalization.");
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // Console.WriteLine("Unmanaged resources are cleaned up here.");

                // TODO: set large fields to null.

                disposedValue = true;
            }
            else
            {
                // Console.WriteLine("Dispose is called more than one time. No need to clean up!");
            }
        }
        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
