﻿using AutoMapper;
using Dapper;
using System.Data;
using VideoUpload_API.Database.Dapper;
using VideoUpload_API.Models;
using VideoUpload_API.Models.Dto;
using VideoUpload_API.Services.Repository.Interface;

namespace VideoUpload_API.Services.Repository.Service
{
    public class SourceRepo : GenericRepository<ClsSourceDto>, ISourceRepo
    {
        #region Property

        ClsDbConnection ConnectionManager;
        private IConfiguration configuration { get; set; }
        private IMapper mapper;

        #endregion

        #region Constructor
        public SourceRepo(IConfiguration _configuration , IMapper _mapper) : base(_configuration)
        {
            configuration = _configuration;
            mapper = _mapper;
            ConnectionManager = ClsDbConnection.SingleInstance;
        }

        #endregion

        #region Destructor
        ~SourceRepo()
        {
            Dispose(false);
        }

        #endregion


        public ClsSourceDto getSourceDetailsUsingSourceName(string sourceName)
        {
            try
            {
                string getSourceQry = @"SELECT * 
                               FROM mstSource 
                               WHERE SourceName = @SourceName and IsActive = 1";

                using (IDbConnection cn = ConnectionManager.getConnectionString(configuration))
                {
                    ClsSource? source = cn.QueryFirstOrDefault<ClsSource>(
                        getSourceQry,
                        new { SourceName = sourceName });

                    if (source == null)
                        return null;

                    ClsSourceDto sourceDto = mapper.Map<ClsSourceDto>(source);

                    return sourceDto;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        public override Task<int> InsertAsync(ClsSourceDto entity)
        {
            throw new NotImplementedException();
        }
        public override Task<IEnumerable<ClsSourceDto>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public override Task<ClsSourceDto> FindAsync(int id)
        {
            throw new NotImplementedException();
        }

        public override Task<int> UpdateAsync(ClsSourceDto entityToUpdate)
        {
            throw new NotImplementedException();
        }

        public override Task<int> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }


        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                // Console.WriteLine("This is the first call to Dispose. Necessary clean-up will be done!");

                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                    // Console.WriteLine("Explicit call: Dispose is called by the user.");
                }
                else
                {
                    // Console.WriteLine("Implicit call: Dispose is called through finalization.");
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // Console.WriteLine("Unmanaged resources are cleaned up here.");

                // TODO: set large fields to null.

                disposedValue = true;
            }
            else
            {
                // Console.WriteLine("Dispose is called more than one time. No need to clean up!");
            }
        }
        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
