﻿using VideoUpload_API.Services.Repository.Interface;
using VideoUpload_API.Services.Repository.Service;

namespace VideoUpload_API.Services.Repository.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        #region Properties

        private IConfiguration _configuration;

        private ISessionRecordingRepo _sessionRecRepository;

        public ISessionRecordingRepo SessionRecording =>
            _sessionRecRepository ?? (_sessionRecRepository = new SessionRecordingRepo(_configuration));

        #endregion

        #region Constructor

        public UnitOfWork(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        #endregion


        #region IDisposable Support

        private bool disposedValue = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                disposedValue = true;
            }
        }

        ~UnitOfWork()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
