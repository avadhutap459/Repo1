﻿using VideoUpload_API.Services.Repository.Interface;

namespace VideoUpload_API.Services.Repository.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        ISessionRecordingRepo SessionRecording { get; }
        ISourceRepo SourceRepo { get; }
    }
}
