﻿using System.Security.Cryptography;
using System.Text;

namespace VideoUpload_API.Services.Repository.Helper
{
    public static class AesEncryptionHelper
    {
        // =======================================
        // ENCRYPT
        // Input: JSON string + 32-character key
        // Output: Base64 (IV + Ciphertext)
        // Compatible with JavaScript AES-CBC
        // =======================================

        public static string Encrypt(string payload, string keyString)
        {
            byte[] key = Encoding.UTF8.GetBytes(keyString);

            if (key.Length != 32)
            {
                throw new ArgumentException(
                    "AES-256 key must be exactly 32 bytes.");
            }

            // Generate random 16-byte IV
            byte[] iv = RandomNumberGenerator.GetBytes(16);

            using var aes = Aes.Create();

            aes.KeySize = 256;
            aes.BlockSize = 128;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            aes.Key = key;
            aes.IV = iv;

            byte[] plaintext = Encoding.UTF8.GetBytes(payload);

            using var encryptor = aes.CreateEncryptor();

            byte[] ciphertext = encryptor.TransformFinalBlock(
                plaintext,
                0,
                plaintext.Length);

            // Combine IV + ciphertext
            byte[] combined = new byte[iv.Length + ciphertext.Length];

            Buffer.BlockCopy(
                iv,
                0,
                combined,
                0,
                iv.Length);

            Buffer.BlockCopy(
                ciphertext,
                0,
                combined,
                iv.Length,
                ciphertext.Length);

            return Convert.ToBase64String(combined);
        }


        // =======================================
        // DECRYPT
        // Input: Base64 encrypted string + 32-character key
        // Output: Original JSON string
        // Compatible with JavaScript AES-CBC
        // =======================================

        public static string Decrypt(
            string encryptedBase64,
            string keyString)
        {
            byte[] key = Encoding.UTF8.GetBytes(keyString);

            if (key.Length != 32)
            {
                throw new ArgumentException(
                    "AES-256 key must be exactly 32 bytes.");
            }

            // Decode Base64 encrypted data
            byte[] combined = Convert.FromBase64String(
                encryptedBase64);

            // IV + at least one ciphertext block
            if (combined.Length < 32 || combined.Length % 16 != 0)
            {
                throw new ArgumentException(
                    "Invalid encrypted data.");
            }

            // Extract IV (first 16 bytes)
            byte[] iv = new byte[16];

            Buffer.BlockCopy(
                combined,
                0,
                iv,
                0,
                iv.Length);

            // Extract ciphertext (remaining bytes)
            byte[] ciphertext = new byte[
                combined.Length - iv.Length];

            Buffer.BlockCopy(
                combined,
                iv.Length,
                ciphertext,
                0,
                ciphertext.Length);

            using var aes = Aes.Create();

            aes.KeySize = 256;
            aes.BlockSize = 128;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            aes.Key = key;
            aes.IV = iv;

            using var decryptor = aes.CreateDecryptor();

            byte[] plaintext = decryptor.TransformFinalBlock(
                ciphertext,
                0,
                ciphertext.Length);

            return Encoding.UTF8.GetString(plaintext);
        }
    }
}