﻿using System.Text.Json;
using VideoUpload_API.Models.Dto;

namespace VideoUpload_API.Services.Repository.Interface
{
    public interface ISessionRecordingRepo : IGenericRepository<ClsVideoSubmitDto>
    {
        Task SaveChunkAsync(Guid sessionId, int chunkNumber, string rootFolder, string appName, JsonElement events, CancellationToken cancellationToken);
        Task<Guid> CreateSessionAsync(string appName);
    }
}
