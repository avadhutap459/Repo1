﻿namespace VideoUpload_API.Services.Repository.Interface
{
    public interface IGenericRepository<T>
    {
        Task<int> InsertAsync(T entity);
        Task<IEnumerable<T>> GetAllAsync();
        Task<T> FindAsync(int id);
        Task<int> DeleteAsync(int id);
        Task<int> UpdateAsync(T entityToUpdate);
    }
}
