﻿using VideoUpload_API.Models.Dto;

namespace VideoUpload_API.Services.Repository.Interface
{
    public interface ISourceRepo : IGenericRepository<ClsSourceDto>
    {
        ClsSourceDto getSourceDetailsUsingSourceName(string sourceName);
    }
}
