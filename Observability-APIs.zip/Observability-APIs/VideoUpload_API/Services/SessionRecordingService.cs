﻿using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace VideoUpload_API.Services
{
    public sealed class SessionRecordingService
    {
        private readonly ILogger<SessionRecordingService> _logger;

        public SessionRecordingService(
            ILogger<SessionRecordingService> logger)
        {
            _logger = logger;
        }

        public async Task SaveChunkAsync(
            Guid sessionId,
            int chunkNumber,
            string rootFolder,
            string appName,
            JsonElement events,
            CancellationToken cancellationToken)
        {
            try
            {
                if (sessionId == Guid.Empty)
                    throw new ArgumentException("Invalid session ID.");

                if (chunkNumber < 0)
                    throw new ArgumentOutOfRangeException(
                        nameof(chunkNumber));

                if (events.ValueKind != JsonValueKind.Array)
                    throw new ArgumentException(
                        "Events must be a JSON array.");

                // S3 folder structure is represented by object prefixes.
                // No physical folder creation is required.

                rootFolder = rootFolder + "SessionRecording" + "\\" + appName;

                string sessionFolder = Path.Combine(rootFolder, sessionId.ToString("D"));

                string chunkFolder = Path.Combine(sessionFolder, "chunks");

                // Create folder if does not exit
                Directory.CreateDirectory(chunkFolder);

                // Generate chunk file name
                var filename = $"{chunkNumber:DB}.json";

                string filePath = Path.Combine(chunkFolder, filename);

                // Generate JSON payload
                var payload = JsonSerializer.Serialize(new
                {
                    sessionId,
                    chunkNumber,
                    uploadedUtc = DateTimeOffset.UtcNow,
                    events
                });

                var bytes = Encoding.UTF8.GetBytes(payload);

                // Generate SHA-256 hash
                var hash = Convert.ToHexString(
                    SHA256.HashData(bytes));

                // Prevent overwriting an eisting chunk

                await using (var fileStream = new FileStream(filePath, FileMode.CreateNew, FileAccess.Write, FileShare.None, bufferSize: 81920, useAsync: true))
                {
                    await fileStream.WriteAsync(bytes, cancellationToken);
                }

                var hashFilePath = filePath + ".sha256";

                await File.WriteAllTextAsync(hashFilePath, hash, cancellationToken);

                _logger.LogInformation("Session chunk save locally. SessionId: {sessionId} , Chunk: {chunkNumber}, Path: {FilePath}", sessionId, chunkNumber, filePath);
            }
            catch (IOException ex) 
                when(ex.Message.Contains("exist", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException("This session chunk already exits", ex);
            } 
            catch(Exception ex)
            {
                _logger.LogError(ex, "Failed to save session chunk locally. SessionId: {sessionId} , Chunk : {chunkNumber}", sessionId, chunkNumber);
                throw;
            }
        }



    }
}
