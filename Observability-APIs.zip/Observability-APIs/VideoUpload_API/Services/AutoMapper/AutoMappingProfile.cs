﻿using AutoMapper;
using VideoUpload_API.Models;
using VideoUpload_API.Models.Dto;

namespace VideoUpload_API.Services.AutoMapper
{
    public class AutoMappingProfile : Profile
    {
        public AutoMappingProfile()
        {
            CreateMap<ClsVideoUpload, ClsVideoUploadDto>();
            CreateMap<ClsVideoSubmit, ClsVideoSubmitDto>();
            CreateMap<ClsSource, ClsSourceDto>();
        }
    }
}
