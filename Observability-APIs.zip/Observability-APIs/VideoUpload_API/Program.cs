using VideoUpload_API.Services;
using VideoUpload_API.Services.AutoMapper;
using VideoUpload_API.Services.Repository.UnitOfWork;

var builder = WebApplication.CreateBuilder(args);

var config = new ConfigurationBuilder().SetBasePath(System.Environment.CurrentDirectory).AddJsonFile("appsettings.json").Build();
string env = config.GetSection("Env").Value;
var configuration = new ConfigurationBuilder().SetBasePath(System.Environment.CurrentDirectory)
                           .AddJsonFile($"appsettings.{env}.json", optional: false, reloadOnChange: true)
                           .Build();

// Add services to the container.

builder.Services.AddControllers();
//builder.Services.AddScoped<SessionRecordingService>();
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();
builder.Services.AddAutoMapper(typeof(AutoMappingProfile).Assembly);
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSessionCapture", policy =>
    {
        policy
            .WithOrigins("https://localhost:7131")
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("AllowSessionCapture");
app.UseAuthorization();

app.MapControllers();

app.Run();
