﻿namespace VideoUpload_API.Models.Dto
{
    public class ClsVideoUploadDto
    {
        public int uploadId { get; set; }
        public int chunknumber { get; set; }
        public string chunknofilename { get; set; } = string.Empty;
        public string appname { get; set; } = string.Empty;
        public string sessionid { get; set; } = string.Empty;
        public DateTime CreationAt { get; set; }
    }
}
