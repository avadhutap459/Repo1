﻿namespace VideoUpload_API.Models.Dto
{
    public class ClsVideoSubmitDto
    {
        public string sessionId { get; set; } = string.Empty;
        public string appname { get; set; } = string.Empty;
        public bool IsActive { get; set; }
        public bool Iscombinchunk { get; set; }
        public bool IsMp4converstion { get; set; }
        public DateTime CreationAt { get; set; }
        public DateTime LastModifiedAt { get; set; }
    }
}
