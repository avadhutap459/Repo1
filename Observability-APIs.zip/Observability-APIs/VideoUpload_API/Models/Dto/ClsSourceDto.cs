﻿namespace VideoUpload_API.Models.Dto
{
    public class ClsSourceDto
    {
        public int SourceId { get; set; }
        public string SourceName { get; set; } = string.Empty;
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public string EncryptionKey { get; set; } = string.Empty;
    }
}
