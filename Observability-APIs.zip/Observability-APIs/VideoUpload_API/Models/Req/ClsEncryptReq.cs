﻿namespace VideoUpload_API.Models.Req
{
    public class ClsEncryptReq
    {
        public string SourceName { get; set; } = string.Empty;
        public string ReqPayload { get; set; } = string.Empty;
    }
}
