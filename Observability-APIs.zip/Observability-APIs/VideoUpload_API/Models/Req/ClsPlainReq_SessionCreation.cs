﻿namespace VideoUpload_API.Models.Req
{
    public class ClsPlainReq_SessionCreation
    {
        public string appName { get; set; } = string.Empty;
    }
}
