﻿namespace VideoUpload_API.Models
{
    public class ClsVideoUpload
    {
        public int uploadId { get; set; }
        public int chunknumber { get; set; }
        public string chunknofilename { get; set; }
        public string appname { get; set; }
        public string sessionid { get; set; }
        public DateTime CreationAt { get; set; }
    }
}
