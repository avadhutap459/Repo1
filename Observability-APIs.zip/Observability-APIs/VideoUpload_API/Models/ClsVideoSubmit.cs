﻿namespace VideoUpload_API.Models
{
    public class ClsVideoSubmit
    {
        public string sessionId { get; set; } = string.Empty;
        public string appname { get; set; } = string.Empty;
        public bool Iscombinchunk { get ; set; }
        public bool IsMp4converstion { get; set; }
        public DateTime CreationAt { get; set; }
        public DateTime LastModifiedAt { get; set; }

    }
}
