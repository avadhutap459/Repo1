﻿namespace VideoUpload_API.Models.Res
{
    public class ClsEncryptRes
    {
        public bool Success { get; set; }
        public string SourceName { get; set; } = string.Empty;
        public string ResPayload { get; set; } = string.Empty;
    }
}
