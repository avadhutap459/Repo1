﻿namespace VideoUpload_API.Models.Res
{
    public class ClsPlainRes
    {
        public bool IsSuccess {  get; set; }
        public int StatusCode { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}
