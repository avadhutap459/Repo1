﻿using System.Text;
using System.Text.Json;
using VideoUpload_API.Models.Dto;
using VideoUpload_API.Models.Req;
using VideoUpload_API.Models.Res;
using VideoUpload_API.Services.Repository.Helper;
using VideoUpload_API.Services.Repository.Service;

namespace VideoUpload_API.Global.Middelware
{
    public class ReqNResConversionAtMiddlewareLevel
    {
        private readonly RequestDelegate _next;

        private static readonly JsonSerializerOptions JsonOptions =
            new JsonSerializerOptions(JsonSerializerDefaults.Web);

        public ReqNResConversionAtMiddlewareLevel(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Apply only to API requests that require encryption.
            if (!context.Request.Path.StartsWithSegments("/api"))
            {
                await _next(context);
                return;
            }

            // Handle requests that don't have a body.
            if (context.Request.ContentLength == 0 ||
                context.Request.Body == Stream.Null)
            {
                await _next(context);
                return;
            }

            ClsEncryptReq? objReqPayload;

            try
            {
                context.Request.EnableBuffering();

                using var reader = new StreamReader(
                    context.Request.Body,
                    Encoding.UTF8,
                    leaveOpen: true);

                string requestJson = await reader.ReadToEndAsync();

                context.Request.Body.Position = 0;

                objReqPayload = JsonSerializer.Deserialize<ClsEncryptReq>(
                    requestJson,
                    JsonOptions);
            }
            catch
            {
                await WriteErrorResponse(
                    context,
                    400,
                    "Invalid encrypted request format",
                    string.Empty);

                return;
            }

            // Validate request envelope.
            if (objReqPayload == null ||
                string.IsNullOrWhiteSpace(objReqPayload.SourceName) ||
                string.IsNullOrWhiteSpace(objReqPayload.ReqPayload))
            {
                await WriteErrorResponse(
                    context,
                    400,
                    "Encrypt request does not contain required payload",
                    objReqPayload?.SourceName ?? string.Empty);

                return;
            }

            // Validate SourceName using ISourceRepo
            ClsSourceDto? objSource =
                sourceRepo.getSourceDetailsUsingSourceName(
                    objReqPayload.SourceName);

            // Source does not exist
            if (objSource == null)
            {
                await WriteErrorResponse(
                    context,
                    400,
                    "Invalid SourceName",
                    objReqPayload.SourceName,
                    fallbackEncryptionKey);

                return;
            }

            // Source exists, but is inactive
            if (!objSource.IsActive)
            {
                await WriteErrorResponse(
                    context,
                    400,
                    "Inactive Source",
                    objReqPayload.SourceName,
                    objSource.EncryptionKey);

                return;
            }

            string plainRequest;

            // Decrypt request payload
            try
            {
                plainRequest = AesEncryptionHelper.Decrypt(
                    objReqPayload.ReqPayload,
                    objSource.EncryptionKey);
            }
            catch
            {
                await WriteErrorResponse(
                    context,
                    400,
                    "Unable to decrypt request payload",
                    objReqPayload.SourceName,
                    objSource.EncryptionKey);

                return;
            }

            // Replace encrypted request body with decrypted JSON.
            byte[] plainRequestBytes = Encoding.UTF8.GetBytes(plainRequest);

            context.Request.Body = new MemoryStream(plainRequestBytes);
            context.Request.ContentLength = plainRequestBytes.Length;
            context.Request.ContentType = "application/json";

            // Capture the plain response returned by the controller.
            Stream originalResponseBody = context.Response.Body;

            using var responseBuffer = new MemoryStream();

            context.Response.Body = responseBuffer;

            try
            {
                // Execute controller/action.
                await _next(context);

                // Read plain controller response.
                responseBuffer.Position = 0;

                string plainResponse = await new StreamReader(
                    responseBuffer,
                    Encoding.UTF8).ReadToEndAsync();

                // Restore the original response stream.
                context.Response.Body = originalResponseBody;

                // Encrypt controller response.
                string encryptedResponse =
                    AesEncryptionHelper.Encrypt(
                        plainResponse,
                        objSource.EncryptionKey);

                ClsEncryptRes objEncryptRes = new ClsEncryptRes
                {
                    ResPayload = encryptedResponse,
                    SourceName = objReqPayload.SourceName,
                    Success = context.Response.StatusCode >= 200 &&
                              context.Response.StatusCode < 300
                };

                string encryptedResponseJson =
                    JsonSerializer.Serialize(objEncryptRes, JsonOptions);

                byte[] responseBytes =
                    Encoding.UTF8.GetBytes(encryptedResponseJson);

                // Replace response content with encrypted envelope.
                context.Response.ContentLength = responseBytes.Length;
                context.Response.ContentType = "application/json";

                await originalResponseBody.WriteAsync(responseBytes);
            }
            catch
            {
                context.Response.Body = originalResponseBody;
                throw;
            }
            finally
            {
                context.Request.Body = originalResponseBody;
                context.Response.Body = originalResponseBody;
            }
        }

        private static async Task WriteErrorResponse(
            HttpContext context,
            int statusCode,
            string message,
            string sourceName,
            string encryptionKey)
        {
            context.Response.Clear();
            context.Response.StatusCode = statusCode;
            context.Response.ContentType = "application/json";

            string encryptedMessage = AesEncryptionHelper.Encrypt(
      message,
      encryptionKey);

            ClsEncryptRes objEncryptRes = new ClsEncryptRes
            {
                ResPayload = encryptedMessage,
                SourceName = sourceName,
                Success = false
            };

            string responseJson = JsonSerializer.Serialize(
                objEncryptRes,
                JsonOptions);

            await context.Response.WriteAsync(responseJson);
        }
    }
}
}
