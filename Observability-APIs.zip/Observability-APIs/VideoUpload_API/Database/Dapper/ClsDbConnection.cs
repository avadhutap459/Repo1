﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace VideoUpload_API.Database.Dapper
{
    public class ClsDbConnection
    {
        private static ClsDbConnection _singleInstance;
        private static readonly object lockObject = new object();
        private ClsDbConnection()
        {
        }

        public static ClsDbConnection SingleInstance
        {
            get
            {
                lock (lockObject)
                {
                    if (_singleInstance == null)
                    {
                        _singleInstance = new ClsDbConnection();
                    }

                }
                return _singleInstance;
            }
        }
        public IDbConnection getConnectionString(IConfiguration configuration)
        {
            try
            {
                string nameOfConnectionString = "DefaultConnection";

                return new SqlConnection(configuration.GetConnectionString(nameOfConnectionString));
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
