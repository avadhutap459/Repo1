﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Text.Json;
using VideoUpload_API.Models.Dto;
using VideoUpload_API.Models.Req;
using VideoUpload_API.Models.Res;
using VideoUpload_API.Services;
using VideoUpload_API.Services.Repository.Helper;
using VideoUpload_API.Services.Repository.UnitOfWork;

namespace VideoUpload_API.Controllers
{
    [Route("api/session-capture")]
    [ApiController]
    public class SessionCaptureController : ControllerBase
    {
        private IUnitOfWork _uowRepo;
        private readonly IConfiguration _configuration;

        public SessionCaptureController(IUnitOfWork unitOfWork,
            IConfiguration configuration)
        {
            _uowRepo = unitOfWork;
            _configuration = configuration;
        }

        public sealed record UploadChunkRequest(
            int ChunkNumber,
            string AppName,
            JsonElement Events);


        [HttpPost("create-session")]
        //public async Task<IActionResult> CreateSession([FromQuery] string appName)
        public async Task<IActionResult> CreateSession([FromBody] ClsEncryptReq objReqPayload)
        {
            string key = _configuration.GetValue<string>("Encryption:Key")??"";
            string PlainResPayloadInSerialize = string.Empty;
            string EncryptResPayload = string.Empty;
            ClsPlainRes objPlainRes = null;
            ClsSourceDto clsSourceDto = null;
            try
            {
                clsSourceDto = _uowRepo.SourceRepo.getSourceDetailsUsingSourceName(objReqPayload.SourceName);

                if (clsSourceDto == null)
                {
                    objPlainRes = new() { IsSuccess = false, StatusCode = (int)HttpStatusCode.BadRequest, Message = "Encrypt Request does not contain encrypt payload" };
                    PlainResPayloadInSerialize = JsonSerializer.Serialize(objPlainRes);
                    EncryptResPayload = AesEncryptionHelper.Encrypt(PlainResPayloadInSerialize, key);
                    return BadRequest(new { Response = new ClsEncryptRes { ResPayload = EncryptResPayload, SourceName = objReqPayload.SourceName, Success = false } });
                }

                if (string.IsNullOrEmpty(objReqPayload.ReqPayload))
                {
                    objPlainRes = new() { IsSuccess = false, StatusCode = (int)HttpStatusCode.BadRequest, Message = "Encrypt Request does not contain encrypt payload" };
                    PlainResPayloadInSerialize = JsonSerializer.Serialize(objPlainRes);
                    EncryptResPayload = AesEncryptionHelper.Encrypt(PlainResPayloadInSerialize, key);
                    return BadRequest(new { Response = new ClsEncryptRes { ResPayload = EncryptResPayload, SourceName = objReqPayload.SourceName, Success = false } });
                }

                string plainReq = AesEncryptionHelper.Decrypt(objReqPayload.ReqPayload, key);

                string appName = "BAWC";
                if (string.IsNullOrWhiteSpace(appName))
                {
                    return BadRequest(new
                    {
                        message = "AppName is required."
                    });
                }

                Guid sessionId = await _uowRepo.SessionRecording.CreateSessionAsync(appName);

                return Ok(new
                {
                    sessionId
                });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new
                    {
                        error = ex.Message
                    });
            }
        }


        [HttpPost("{sessionId:guid}/chunks")]
        [RequestSizeLimit(2_000_000)]
        public async Task<IActionResult> UploadChunk(
            Guid sessionId,
            [FromBody] UploadChunkRequest request,
            CancellationToken cancellationToken)
        {
            if (sessionId == Guid.Empty)
                return BadRequest("Invalid session ID.");

            if (request.ChunkNumber < 0)
                return BadRequest("Chunk number must be non-negative.");

            if (request.Events.ValueKind != JsonValueKind.Array)
                return BadRequest("Events must be a JSON array.");

            var maxBytes = _configuration.GetValue<int>(
                "SessionReplay:MaxChunkBytes", 2_000_000);

            if (Request.ContentLength is long length &&
                length > maxBytes)
            {
                return StatusCode(413, "Chunk is too large.");
            }

            try
            {
                string rootFolder = _configuration.GetValue<string>("rootPath");

                await _uowRepo.SessionRecording.SaveChunkAsync(
                    sessionId,
                    request.ChunkNumber,
                    rootFolder,
                    request.AppName,
                    request.Events,
                    cancellationToken);

                return Ok(new
                {
                    sessionId,
                    request.ChunkNumber,
                    uploaded = true
                });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { error = ex.Message });
            }
        }
    }
}
