﻿using System.Text.Json;

namespace CombineChunk_API.Services
{
    public sealed class SessionRecordingService
    {
        private readonly ILogger<SessionRecordingService> _logger;

        public SessionRecordingService(
            ILogger<SessionRecordingService> logger)
        {
            _logger = logger;
        }

        public int GetLastChunkNumberBaseOnSessionId(Guid sessionId)
        {
            string _sessionId = sessionId.ToString("D");

            try
            {
                int LastChunkNumber = 0;

                // logic

                return LastChunkNumber;
            }
            catch(Exception ex)
            {
                throw;
            }

        }

        public string GetAppNameBaseOnSessionId(Guid sessionId)
        {
            string _sessionId = sessionId.ToString("D");
            try
            {
                string appName = string.Empty;

                //logic

                return appName;
            }
            catch(Exception ex)
            {
                throw;
            }
        }

        public async Task<int> CombineChunksAsync(
            Guid sessionId,
            string outputFile,
            string chunkDirectory,
            int expectedLastChunkNumber,
            CancellationToken cancellationToken)
        {
            // STEP 1: Validate inputs

            if (sessionId == Guid.Empty)
            {
                throw new ArgumentException(
                    "Invalid session ID.",
                    nameof(sessionId));
            }

            if (string.IsNullOrWhiteSpace(outputFile))
            {
                throw new ArgumentException(
                    "Output file path is required.",
                    nameof(outputFile));
            }

            if (expectedLastChunkNumber < 0 ||
                expectedLastChunkNumber == int.MaxValue)
            {
                throw new ArgumentOutOfRangeException(
                    nameof(expectedLastChunkNumber),
                    "Invalid last chunk number.");
            }

            // STEP 2: Construct local chunk folder

            if (!Directory.Exists(chunkDirectory))
            {
                throw new InvalidOperationException(
                    $"Chunk directory not found for session {sessionId}.");
            }

            _logger.LogInformation(
                "Reading local session chunks. Session: {SessionId}, Expected last chunk: {LastChunk}",
                sessionId,
                expectedLastChunkNumber);

            // STEP 3: Read JSON chunk files from local storage

            var chunkFiles = Directory
                .GetFiles(chunkDirectory, "*.json")
                .Select(file => new
                {
                    FilePath = file,
                    Number = ParseChunkNumber(file)
                })
                .OrderBy(item => item.Number)
                .ToList();

            if (chunkFiles.Count == 0)
            {
                throw new InvalidOperationException(
                    $"No JSON chunks found for session {sessionId}.");
            }

            // STEP 4: Validate expected chunk count

            var expectedChunkCount =
                expectedLastChunkNumber + 1;

            if (chunkFiles.Count != expectedChunkCount)
            {
                throw new InvalidOperationException(
                    $"Incomplete session recording. " +
                    $"Expected {expectedChunkCount} chunks " +
                    $"(0 to {expectedLastChunkNumber}), " +
                    $"but found {chunkFiles.Count} chunks.");
            }

            // STEP 5: Validate continuous chunk numbering

            for (var i = 0; i < expectedChunkCount; i++)
            {
                if (chunkFiles[i].Number != i)
                {
                    throw new InvalidOperationException(
                        $"Missing or invalid chunk sequence. " +
                        $"Expected chunk {i}, found {chunkFiles[i].Number}.");
                }
            }

            _logger.LogInformation(
                "Local chunk validation successful. Session: {SessionId}, ChunkCount: {ChunkCount}",
                sessionId,
                chunkFiles.Count);

            // STEP 6: Validate output path

            var fullOutputPath = Path.GetFullPath(outputFile);

            var outputDirectory = Path.GetDirectoryName(
                fullOutputPath);

            if (string.IsNullOrWhiteSpace(outputDirectory))
            {
                throw new InvalidOperationException(
                    "Invalid output file directory.");
            }

            Directory.CreateDirectory(outputDirectory);

            var totalEvents = 0;

            try
            {
                // STEP 7: Create combined JSON file

                await using var outputStream = new FileStream(
                    fullOutputPath,
                    FileMode.Create,
                    FileAccess.Write,
                    FileShare.None,
                    bufferSize: 64 * 1024,
                    useAsync: true);

                using var writer = new Utf8JsonWriter(
                    outputStream);

                writer.WriteStartArray();

                // STEP 8: Process chunks in sequence

                foreach (var chunk in chunkFiles)
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    _logger.LogInformation(
                        "Processing local chunk {ChunkNumber}: {FilePath}",
                        chunk.Number,
                        chunk.FilePath);

                    await using var chunkStream = new FileStream(
                        chunk.FilePath,
                        FileMode.Open,
                        FileAccess.Read,
                        FileShare.Read,
                        bufferSize: 64 * 1024,
                        useAsync: true);

                    using var document = await JsonDocument.ParseAsync(
                        chunkStream,
                        cancellationToken: cancellationToken);

                    var root = document.RootElement;

                    if (root.ValueKind != JsonValueKind.Object)
                    {
                        throw new InvalidOperationException(
                            $"Invalid JSON chunk structure: {chunk.FilePath}.");
                    }

                    // STEP 9: Validate stored session ID

                    if (!root.TryGetProperty(
                            "sessionId",
                            out var storedSessionId) ||
                        storedSessionId.ValueKind != JsonValueKind.String ||
                        !Guid.TryParse(
                            storedSessionId.GetString(),
                            out var parsedSessionId) ||
                        parsedSessionId != sessionId)
                    {
                        throw new InvalidOperationException(
                            $"Session ID mismatch in chunk {chunk.Number}.");
                    }

                    // STEP 10: Validate stored chunk number

                    if (!root.TryGetProperty(
                            "chunkNumber",
                            out var storedChunkNumber) ||
                        !storedChunkNumber.TryGetInt32(
                            out var actualChunkNumber) ||
                        actualChunkNumber != chunk.Number)
                    {
                        throw new InvalidOperationException(
                            $"Chunk number mismatch in chunk {chunk.Number}.");
                    }

                    // STEP 11: Extract events

                    if (!root.TryGetProperty(
                            "events",
                            out var events) ||
                        events.ValueKind != JsonValueKind.Array)
                    {
                        throw new InvalidOperationException(
                            $"Events array missing in chunk {chunk.Number}.");
                    }

                    foreach (var item in events.EnumerateArray())
                    {
                        item.WriteTo(writer);
                        totalEvents++;
                    }

                    _logger.LogInformation(
                        "Chunk processed. Session: {SessionId}, Chunk: {ChunkNumber}, Events: {EventCount}",
                        sessionId,
                        chunk.Number,
                        events.GetArrayLength());
                }

                // STEP 12: Validate events

                if (totalEvents == 0)
                {
                    throw new InvalidOperationException(
                        "No rrweb events found in the session chunks.");
                }

                writer.WriteEndArray();

                await writer.FlushAsync(cancellationToken);

                _logger.LogInformation(
                    "Session chunks combined successfully. " +
                    "Session: {SessionId}, Chunks: {ChunkCount}, " +
                    "Events: {EventCount}, Output: {OutputFile}",
                    sessionId,
                    chunkFiles.Count,
                    totalEvents,
                    fullOutputPath);

                return totalEvents;
            }
            catch
            {
                // Remove incomplete output if combination fails

                if (File.Exists(fullOutputPath))
                {
                    try
                    {
                        File.Delete(fullOutputPath);
                    }
                    catch (Exception cleanupException)
                    {
                        _logger.LogWarning(
                            cleanupException,
                            "Unable to remove incomplete events file: {OutputFile}",
                            fullOutputPath);
                    }
                }

                throw;
            }
        }



        private static int ParseChunkNumber(string filePath)
        {
            var fileName = Path.GetFileNameWithoutExtension(filePath);

            if (!int.TryParse(fileName, out var chunkNumber) ||
                chunkNumber < 0)
            {
                throw new InvalidOperationException(
                    $"Invalid chunk file name: {filePath}");
            }

            return chunkNumber;
        }
    }
}
