﻿using CombineChunk_API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CombineChunk_API.Controllers
{
    [Route("api/session-combin")]
    [ApiController]
    public class SessionCombinController : ControllerBase
    {
        private readonly SessionRecordingService _recordingService;
        private readonly IConfiguration _configuration;

        public SessionCombinController(
            SessionRecordingService recordingService,
            IConfiguration configuration)
        {
            _recordingService = recordingService;
            _configuration = configuration;
        }

        [HttpPost("{sessionId:guid}/combine")]
        public async Task<IActionResult> Combine(
            Guid sessionId,
            CancellationToken cancellationToken)
        {
            int expectedLastChunkNumber = 0;
            string appName  = string.Empty;

            if (sessionId == Guid.Empty)
            {
                return BadRequest("Invalid session ID.");
            }

            /// Get chunk number from DB
            /// 
            expectedLastChunkNumber = _recordingService.GetLastChunkNumberBaseOnSessionId(sessionId);

            if (expectedLastChunkNumber < 0)
            {
                return BadRequest("Invalid last chunk number.");
            }

            appName = _recordingService.GetAppNameBaseOnSessionId(sessionId);

            var storagePath = _configuration["rootPath"] + "\\" + "SessionRecording";

            if (string.IsNullOrWhiteSpace(storagePath))
            {
                return StatusCode(
                    500,
                    "Session recording storage path is not configured.");
            }

            var outputDirectory = Path.Combine(
                storagePath,
                appName,
                sessionId.ToString("D"));

            var chunkDirectory = Path.Combine(
                storagePath,
                appName,
                sessionId.ToString("D"),
                "chunks");

            var outputFile = Path.Combine(
                outputDirectory, sessionId + ".json");

            try
            {
                var totalEvents =
                    await _recordingService.CombineChunksAsync(
                        sessionId,
                        outputFile,
                        chunkDirectory,
                        expectedLastChunkNumber,
                        cancellationToken);

                return Ok(new
                {
                    sessionId,
                    totalEvents,
                    fileName = Path.GetFileName(outputFile),
                    outputFile,
                    status = "Combined successfully"
                });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new
                {
                    message = ex.Message
                });
            }
            catch (Exception ex)
            {
                return Problem(
                    title: "Unable to combine session chunks.",
                    detail: ex.Message,
                    statusCode: 500);
            }
        }



    }
}
